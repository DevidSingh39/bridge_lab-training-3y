
// 1. Show Courses
function showCourses() {
    alert("You have 5 courses available.");
}


// 2. Show Assignments
function showAssignments() {
    alert("You have 3 pending assignments.");
}


// 3. Show Profile
function showProfile() {
    alert("Your Profile: Student");
}


// 4. Dashboard Welcome Message
function showDashboard() {
    updateGreeting();
}


// 5. Logout
function logout() {
    alert("You have been logged out successfully!");
}


// 6. Change Greeting According to Time
function updateGreeting() {

    let today = new Date();

    let hour = today.getHours();

    let greeting = "";

    if (hour >= 5 && hour < 12) {
        greeting = "Good Morning";
    }
    else if (hour >= 12 && hour < 17) {
        greeting = "Good Afternoon";
    }
    else if (hour >= 17 && hour < 21) {
        greeting = "Good Evening";
    }
    else {
        greeting = "Good Night";
    }

    document.getElementById("welcomeHeading").innerHTML =
        greeting + "! Welcome to SkillTracker 👋";
}


// 7. Display Current Date and Time
function updateDateTime() {

    let today = new Date();

    let time = today.toLocaleTimeString();

    let date = today.toDateString();

    document.getElementById("currentTime").innerHTML = time;

    document.getElementById("currentDate").innerHTML = date;

    updateGreeting();
}


// 8. Automatically Update Date and Time
updateDateTime();

setInterval(updateDateTime, 1000);
